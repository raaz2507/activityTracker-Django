from django.db import models

# Create your models here.
# from django.contrib.auth import get_user_model
# users= get_user_model()
class users(models.Model):
    def save(self, *args, **kwargs):
        if not self.usr_id:
            last_user = users.objects.order_by('-id',).first()
            if last_user and last_user.usr_id:
                lastNumber = int(last_user.usr_id.split('_')[1])
                self.usr_id =  f"usr_{lastNumber + 1:02d}"
            else:
                self.usr_id =  "usr_01"
        super().save(*args, **kwargs)


    usr_id =  models.CharField(max_length=10, unique = True, null=False, editable= False)
    user_name = models.CharField( max_length=10 , unique=True, null=False)
    pwd = models.CharField( max_length=4 , null=False)

    def __str__(self):
        return f" User Name: {self.user_name}, password {self.pwd}"



class SourceField(models.TextChoices):
        VIDEO = "v", "Videos"
        BOOK = "b", "Books"
        COMICS = "co", "Comics"
        INTERACTION = "i", "Interaction"
        CHAT = "ch", "Chat"
class Source(models.Model):
    key = models.CharField(max_length=5, choices=SourceField.choices, unique=True)

    def __str__(self):
        return self.get_key_display()
class record(models.Model):
    
    
    class TiggerReasonField(models.TextChoices):
        DIGITAL_VISUALS = 'dv', 'Digital Visuals'
        SOCIAL_INTERACTION = 'si', 'Social Interaction'
        LONG_INACTIVITY = "long", 'Head not do for long time'

    usr_id =  models.ForeignKey( users, on_delete=models.CASCADE )
    cur_date= models.DateField(auto_now_add=True)
    start_time =  models.TimeField()
    end_time =  models.TimeField(auto_now =True)
    videos= models.BooleanField(default=False)
    books= models.BooleanField(default=False)
    comics= models.BooleanField(default=False)
    interaction= models.BooleanField(default=False)
    chat= models.BooleanField(default=False)

    source = models.ManyToManyField( Source)
    tigger_reason = models.CharField(max_length=4, choices= TiggerReasonField.choices, blank=False)
    times = models.IntegerField()

