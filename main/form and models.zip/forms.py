from django import forms
from .models import users, record

class usersForm(forms.ModelForm):
    
    class Meta:
        model =  users
        # fields: '__all__'
        fields = ['user_name', 'pwd']
    labels={
        'user_name': 'User Name',
        'pwd': "Password",
    }
    widgets ={
        'user_name': forms.TextInput(attrs={'class':'', 'placeholder': 'Enter User Name'}),
        'pwd': forms.PasswordInput(attrs={'class': '', 'placeholder': 'Enter Your password'})
    }

class recordForm(forms.ModelForm):
    SOURCE_CHOICES = [
        ("v", "Videos"),
        ("b", "Books"),
        ("co", "Comics"),
        ("i", "Interaction"),
        ("ch", "Chat"),
    ]

    source = forms.MultipleChoiceField(
        choices=SOURCE_CHOICES,
        widget=forms.CheckboxSelectMultiple,
    )

    def clean_source(self):
        data = self.cleaned_data['source']
        return ",".join(data)  # Store as comma-separated string

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Load initial data from comma string
        if self.instance and self.instance.source:
            self.initial['source'] = self.instance.source.split(",")

        # Required fields
        self.fields['tigger_reason'].required = True
        self.fields['source'].required = True


    class Meta:
        model = record
        fields = '__all__'
        exclude = ['usr_id' ]
        labels={
            'cur_date': 'current Date',
            'start_time' : 'Current Time',
            'end_time' : 'Finsh Time',
            'source': 'source',
            'tigger_reason': 'Tigger Reason',
            'times': 'Times'
        }
        widgets={
            'cur_date': forms.DateInput(),
            'start_time' : forms.TimeInput(),
            'end_time' : forms.TimeInput(),
            'source': forms.CheckboxSelectMultiple(),
            'tigger_reason': forms.RadioSelect(),
            'times': forms.NumberInput() 
        }
# class recordForm(forms.ModelForm):
#     class Meta:
#         model = record
#         fields = '__all__'
#         exclude = ['usr_id']
#         labels = {
#             'cur_date': 'current Date',
#             'start_time': 'Current Time',
#             'end_time': 'Finish Time',
#             # 'source': 'source',
#             'tigger_reason': 'Trigger Reason',
#             'times': 'Times'
#         }
#         widgets = {
#             'cur_date': forms.DateInput(),
#             'start_time': forms.TimeInput(),
#             'end_time': forms.TimeInput(),
#             'vieos': forms.BooleanField,
#             # 'source': forms.CheckboxSelectMultiple(),
#             # 'source': forms.CheckboxSelectMultiple(),  # ManyToMany को handle करेगा
#             'tigger_reason': forms.RadioSelect(),
#             'times': forms.NumberInput()
#         }
